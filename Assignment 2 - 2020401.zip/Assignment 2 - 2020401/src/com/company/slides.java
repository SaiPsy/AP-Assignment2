package com.company;

import java.util.Date;

public class slides implements lectures {
    protected String slides_topic;
    private int slides_num;
    private Date date;
    private String slide_content;
    private int instructorLoggedIn;

    public slides(String slides_topic, int slides_num, String slide_content, int instructorLoggedIn) {
        this.slides_topic=slides_topic;
        this.slides_num=slides_num;
        this.slide_content=slide_content;
        this.date= new Date();
        this.instructorLoggedIn=instructorLoggedIn;
    }

    @Override
    public void showDetails() {
        System.out.println("Slides Topic: "+ slides_topic + "\nNumber of slides: " + slides_num + "\nUpload date: " + date + "\nInstructor Name: " + instructorLoggedIn);
    }
}
