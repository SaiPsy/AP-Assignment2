package com.company;

import java.util.ArrayList;

public class instructor {
    private String ins_Name;
    instructor(String ins_Name){
        this.ins_Name=ins_Name;
    }


}
