package com.company;

public class quiz implements assessments{
    private String quizQues;
    private int instructorLoggedIn;

    public quiz(String quizQues, int instructorLoggedIn) {
        super();
        this.quizQues=quizQues;
        this.instructorLoggedIn=instructorLoggedIn;
    }

    @Override
    public void showDetails() {
        System.out.println("Assignment Question: "+ quizQues + "\nInstructor Name: " + instructorLoggedIn);
    }

}
