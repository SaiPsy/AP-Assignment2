package com.company;

import java.util.*;

public class videos implements lectures {
    protected String video_topic;
    private String fileName;
    private Date date;
    private int instructorLoggedIn;

    public videos(String video_topic, String fileName, int instructorLoggedIn) {
        this.video_topic=video_topic;
        this.fileName=fileName;
        this.date= new Date();
        this.instructorLoggedIn=instructorLoggedIn;
    }

    @Override
    public void showDetails() {
        System.out.println("Video Title: " + video_topic + "\nFilename: " + fileName + "\nUploaded on " + date + "\nInstructor Name: " + instructorLoggedIn);
    }

}
