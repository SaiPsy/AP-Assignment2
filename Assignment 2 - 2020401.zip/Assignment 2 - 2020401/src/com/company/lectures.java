package com.company;

public interface lectures {
    instructor Instr = null;
    public void showDetails();
}
