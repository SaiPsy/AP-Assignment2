package com.company;

public class student {
    private String stu_name;
    student(String stu_name){
        this.stu_name=stu_name;
    }
}
