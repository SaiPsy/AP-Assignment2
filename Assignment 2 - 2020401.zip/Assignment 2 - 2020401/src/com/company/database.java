package com.company;

import java.util.ArrayList;

public class database {
    static ArrayList<instructor> instructors;
    static ArrayList<slides> slide_details;
    static ArrayList<videos> video_details;
    static ArrayList<assessments> assignment_details;
    static ArrayList<quiz> quiz_details;
    static ArrayList<comments> comments_details;

    database(){
        slide_details = new ArrayList<slides>();
        video_details = new ArrayList<videos>();
        assignment_details = new ArrayList<assessments>();
        quiz_details = new ArrayList<quiz>();
        comments_details = new ArrayList<comments>();

    }
}
