package com.company;

public interface assessments{
    void showDetails();
}
