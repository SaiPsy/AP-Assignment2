package com.company;

public class assignment implements assessments {
    private String prob;
    private int maxMarks;
    private int instructorLoggedIn;

    public assignment(String prob, int maxMarks, int instructorLoggedIn) {
        this.prob=prob;
        this.maxMarks=maxMarks;
        this.instructorLoggedIn=instructorLoggedIn;
    }

    public void showDetails() {
        System.out.println("Quiz Question: "+ prob + "\nInstructor Name: " + instructorLoggedIn);
    }
}
