package com.company;

import java.util.*;
import java.util.regex.Pattern;

import static com.company.database.*;

public class Main {
    public static void main(String[] args) {
        //Menu based program for LMS
        Scanner sc = new Scanner(System.in).useDelimiter("\n");
        boolean exit = false;
        database Database = new database();
        instructor I0 = new instructor("I0");
        instructor I1 = new instructor("I1");
        student S0 = new student("S0");
        student S1 = new student("S1");
        student S2 = new student("S2");


        while (exit == false) {
            System.out.println("Welcome to Backpack\n" +
                    "1. Enter as instructor\n" +
                    "2. Enter as student\n" +
                    "3. Exit");

            int choice = sc.nextInt();
            if (choice == 1) {
                System.out.println("Instructors: \n0-I0 \n1-I1");
                int instructorLoggedIn = sc.nextInt();
                int instructorChoice = 0;

                while (instructorChoice != 9) {
                    System.out.println("Welcome I" + instructorLoggedIn);
                    System.out.println("1. Add class material\n" +
                            "2. Add assessments\n" +
                            "3. View lecture materials\n" +
                            "4. View assessments\n" +
                            "5. Grade assessments\n" +
                            "6. Close assessment\n" +
                            "7. View comments\n" +
                            "8. Add comments\n" +
                            "9. Logout");
                    instructorChoice = sc.nextInt();

                    if (instructorChoice == 1) {
                        System.out.println("Enter \n1. Lecture Slides\n2. Lecture Videos ");
                        int lectureType = sc.nextInt();

                        if (lectureType == 1) {
                            System.out.print("Enter topic of slides: ");
                            String slides_topic = sc.next();
                            System.out.print("Enter number of slides: ");
                            int slides_num = sc.nextInt();
                            System.out.print("Enter content of slides\n");
                            String slide_content = null;
                            for (int i = 1; i <= slides_num; i++) {
                                System.out.print("Content of slide " + i + ": ");
                                slide_content = sc.next();
                                slides add_slides = new slides(slides_topic, slides_num, slide_content, instructorLoggedIn);
                                slide_details.add(add_slides);
                            }
                            System.out.println("Slides Added");
                        } else if (lectureType == 2) {
                            System.out.println("Enter topic of video: ");
                            String video_topic = sc.next();
                            System.out.println("Enter filename: ");
                            String fileName = sc.next();
                            if (fileName.contains(".")) {
                                String extension = fileName.split(Pattern.quote("."), 2)[1];
                                if (Objects.equals("mp4", extension)) {
                                    videos add_videos = new videos(video_topic, fileName, instructorLoggedIn);
                                    video_details.add(add_videos);
                                    System.out.println("Video added");
                                } else {
                                    System.out.println("We only accept .mp4 format");
                                }
                            } else {
                                System.out.println("Invalid format upload only .mp4");
                            }
                        }
                    } else if (instructorChoice == 2) {
                        System.out.println("Enter \n1. Add Assignment\n2. Add Quiz ");
                        int assessmentType = sc.nextInt();

                        if (assessmentType == 1) {
                            System.out.print("Enter problem statement: ");
                            String prob = sc.next();
                            System.out.print("Enter maximum marks: ");
                            int maxMarks = sc.nextInt();
                            assignment add_assignment = new assignment(prob, maxMarks, instructorLoggedIn);
                            Database.assignment_details.add(add_assignment);
                            System.out.println("Assignment Added");
                        } else if (assessmentType == 2) {
                            System.out.println("Enter quiz ques: ");
                            String quizQues = sc.next();

                            quiz add_quiz = new quiz(quizQues, instructorLoggedIn);
                            quiz_details.add(add_quiz);
                            System.out.println("Quiz Added");
                        }
                    } else if (instructorChoice == 3) {
                        System.out.println("Slides: ");
                        for (int i = 0; i < slide_details.size(); i++) {
                            slide_details.get(i).showDetails();
                        }
                        System.out.println("\nVideos: ");
                        for (int i = 0; i < video_details.size(); i++) {
                            video_details.get(i).showDetails();
                        }
                        System.out.println("");
                    } else if (instructorChoice == 4) {
                        System.out.println("Quiz: ");
                        for (int i = 0; i < quiz_details.size(); i++) {
                            quiz_details.get(i).showDetails();
                        }
                        System.out.println("\nAssignments: ");
                        for (int i = 0; i < assignment_details.size(); i++) {
                            assignment_details.get(i).showDetails();
                        }
                        System.out.println("");
                    } else if (instructorChoice == 5) {

                    } else if (instructorChoice == 7) {
                        for (int i = 0; i < comments_details.size(); i++) {
                            comments_details.get(i).showDetails();
                            System.out.println(" ");
                        }
                        System.out.println("");
                    } else if (instructorChoice == 8) {
                        System.out.println("Enter Comment: ");
                        String theirComment = sc.next();
                        String nameOfSender = "I" + instructorLoggedIn;
                        comments add_comment = new comments(nameOfSender, theirComment);
                        comments_details.add(add_comment);
                        System.out.println("Comments Added");
                    } else if (instructorChoice == 9) {
                        exit = true;
                    }
                }
            } else if (choice == 2) {
                System.out.println("Students: \n0-S0 \n1-S1\n2-S2");
                int studentLoggedIn = sc.nextInt();
                int studentChoice = 0;

                while (studentChoice != 7) {
                    System.out.println("Welcome I" + studentLoggedIn);
                    System.out.println("1. View lecture materials\n" +
                            "2. View assessments\n" +
                            "3. Submit assessment\n" +
                            "4. View grades\n" +
                            "5. View comments\n" +
                            "6. Add comments\n" +
                            "7. Logout");
                    studentChoice = sc.nextInt();

                    if (studentChoice == 1) {
                        System.out.println("Slides: ");
                        for (int i = 0; i < slide_details.size(); i++) {
                            slide_details.get(i).showDetails();
                        }
                        System.out.println("\nVideos: ");
                        for (int i = 0; i < video_details.size(); i++) {
                            video_details.get(i).showDetails();
                        }
                        System.out.println("");
                    }else if (studentChoice == 2) {
                        System.out.println("Quiz: ");
                        for (int i = 0; i < quiz_details.size(); i++) {
                            quiz_details.get(i).showDetails();
                        }
                        System.out.println("\nAssignments: ");
                        for (int i = 0; i < assignment_details.size(); i++) {
                            assignment_details.get(i).showDetails();
                        }
                        System.out.println("");
                    }else if (studentChoice == 5) {
                        for (int i = 0; i < comments_details.size(); i++) {
                            comments_details.get(i).showDetails();
                            System.out.println(" ");
                        }
                        System.out.println("");
                    }else if (studentChoice == 6) {
                        System.out.println("Enter Comment: ");
                        String theirComment = sc.next();
                        String nameOfSender = "S" + studentLoggedIn;
                        comments add_comment = new comments(nameOfSender, theirComment);
                        comments_details.add(add_comment);
                        System.out.println("Comments Added");
                    }
                }
            }
        }
    }
}