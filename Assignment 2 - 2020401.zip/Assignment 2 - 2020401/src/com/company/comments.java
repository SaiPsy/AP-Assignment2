package com.company;

import java.util.*;

public class comments {
    private Date date;
    private String nameOfSender;
    private String theirComment;

    comments(String nameOfSender, String theirComment){
        this.nameOfSender=nameOfSender;
        this.theirComment=theirComment;
        this.date = new Date();
    }

    public void showDetails() {
        System.out.println("Sender Name: " + nameOfSender + "\nComment: " + theirComment + "\nUploaded on " + date);
    }
}
